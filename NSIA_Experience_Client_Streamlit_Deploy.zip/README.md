# NSIA — Expérience Client

Dashboard Streamlit de pilotage de l'expérience client.

## Fonctionnement

L'application fonctionne à partir d'un **fichier Excel DEX central** importé depuis l'interface. Le fichier doit contenir les 6 feuilles métiers :

- `DIGITAL`
- `MESSAGERIE`
- `RC & SATISFACTION`
- `PHYSIQUE`
- `CALLCENTER`
- `DESHERENCE`

L'application valide automatiquement les feuilles et les colonnes avant de charger les données.

## Lancer en local

```bash
pip install -r requirements.txt
streamlit run app.py
```

## Déploiement

Le fichier d'entrée est `app.py`. Le projet est prévu pour **Streamlit Community Cloud**.

Après déploiement, l'utilisateur ouvre le lien de l'application et importe sa base DEX Excel directement dans l'interface.

## Données

Les fichiers Excel importés ne sont pas inclus dans le dépôt Git. Le dossier `data/` est réservé aux fichiers générés temporairement par l'application pendant son exécution.

## Chatbot

Le module chatbot existant est conservé dans le projet, mais il n'est pas nécessaire au fonctionnement du dashboard principal.
