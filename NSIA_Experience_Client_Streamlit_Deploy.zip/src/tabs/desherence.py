import streamlit as st
import pandas as pd

from kpi_dex import desherence_kpis
from periods import (
    GRANULARITES,
    construire_periodes,
    periode_precedente,
)
from charts import afficher_tendance


def _filtrer_periode(df, periode):

    resultat = df.copy()

    if "Date" in resultat.columns:

        dates = pd.to_datetime(
            resultat["Date"],
            errors="coerce",
            dayfirst=True,
        ).dt.normalize()

        resultat = resultat.loc[
            dates.between(
                periode.debut,
                periode.fin,
            )
        ].copy()

    return resultat


def render(df):

    st.markdown("## 📉 Déshérence")

    st.caption(
        "Suivi des indicateurs de déshérence et des appels clients."
    )

    if df is None or df.empty:

        st.warning(
            "Aucune donnée disponible dans la base Déshérence."
        )

        return

    if "Date" not in df.columns:

        st.warning(
            "La colonne Date n'est pas présente dans la base Déshérence."
        )

        return

    dates = pd.to_datetime(
        df["Date"],
        errors="coerce",
        dayfirst=True,
    ).dropna()

    if dates.empty:

        st.warning(
            "Aucune date exploitable dans la base Déshérence."
        )

        return

    dates_df = pd.DataFrame({
        "Date": dates
    })

    col1, col2 = st.columns(2)

    with col1:

        granularite = st.selectbox(
            "Granularité",
            GRANULARITES,
            index=2,
            key="desherence_granularite",
        )

    periodes = construire_periodes(
        dates_df,
        granularite,
    )

    if not periodes:

        st.warning(
            "Aucune période disponible."
        )

        return

    labels = [
        periode.label
        for periode in periodes
    ]

    with col2:

        periode_label = st.selectbox(
            "Période",
            labels,
            index=len(labels) - 1,
            key="desherence_periode",
        )

    periode = next(
        p
        for p in periodes
        if p.label == periode_label
    )

    periode_avant = periode_precedente(
        periode
    )

    df_actuel = _filtrer_periode(
        df,
        periode,
    )

    df_precedent = _filtrer_periode(
        df,
        periode_avant,
    )

    st.info(
        f"📅 **{periode.label}** : "
        f"{periode.debut.strftime('%d/%m/%Y')} → "
        f"{periode.fin.strftime('%d/%m/%Y')} "
        f"| Comparaison : **{periode_avant.label}**"
    )

    kpis_actuels = desherence_kpis(
        df_actuel
    )

    kpis_precedents = {
        kpi["name"]: kpi
        for kpi in desherence_kpis(
            df_precedent
        )
    }

    st.markdown(
        "### 🎯 Indicateurs Déshérence"
    )

    colonnes = st.columns(4)

    for i, kpi in enumerate(
        kpis_actuels
    ):

        precedent = kpis_precedents.get(
            kpi["name"]
        )

        valeur = kpi["value"]

        ancienne = (
            precedent["value"]
            if precedent
            else None
        )

        if valeur is None:

            affichage = "—"

        elif kpi["unit"] == "%":

            affichage = f"{valeur:.1f}%"

        else:

            affichage = (
                f"{valeur:,.1f}"
                .replace(",", " ")
            )

        delta = None

        if (
            valeur is not None
            and ancienne is not None
        ):

            ecart = valeur - ancienne

            if kpi["unit"] == "%":

                delta = f"{ecart:+.1f} pt"

            else:

                delta = (
                    f"{ecart:+,.1f}"
                    .replace(",", " ")
                )

        with colonnes[i % 4]:

            st.metric(
                kpi["name"],
                affichage,
                delta,
            )

    st.markdown("---")

    st.markdown(
        "### 📈 Évolution"
    )

    graph_cols = st.columns(2)

    with graph_cols[0]:
        afficher_tendance(
            df,
            granularite,
            desherence_kpis,
            "Base totale — % clients trouvés (liquidés)",
            couleur="#1769E0",
            key="desherence_trend_base",
        )

    with graph_cols[1]:
        afficher_tendance(
            df,
            granularite,
            desherence_kpis,
            "Sur 2025 — % clients trouvés (liquidés)",
            couleur="#D6A84F",
            key="desherence_trend_2025",
        )

    graph_cols2 = st.columns(2)

    with graph_cols2[0]:
        afficher_tendance(
            df,
            granularite,
            desherence_kpis,
            "% Clients émis (appels)",
            couleur="#20A464",
            key="desherence_trend_emis",
        )

    with graph_cols2[1]:
        afficher_tendance(
            df,
            granularite,
            desherence_kpis,
            "% Clients joints / appels émis",
            couleur="#7048E8",
            key="desherence_trend_joints",
        )

    st.markdown("---")

    st.markdown(
        "### 📋 Données de la période"
    )

    if df_actuel.empty:

        st.info(
            "Aucune donnée pour cette période."
        )

    else:

        st.dataframe(
            df_actuel,
            use_container_width=True,
            height=400,
            key="desherence_donnees_actuelles",
        )