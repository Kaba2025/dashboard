import streamlit as st
import pandas as pd

from kpi_dex import reclamation_kpis
from periods import (
    GRANULARITES,
    construire_periodes,
    periode_precedente,
)
from charts import afficher_tendance


def _filtrer_periode(df, periode):

    resultat = df.copy()

    if "Date" in resultat.columns:

        dates = pd.to_datetime(
            resultat["Date"],
            errors="coerce",
            dayfirst=True,
        ).dt.normalize()

        resultat = resultat.loc[
            dates.between(
                periode.debut,
                periode.fin,
            )
        ].copy()

    return resultat


def render(df):

    st.markdown("## ⚠️ Réclamations")

    st.caption(
        "Suivi des réclamations clients et de leur traitement."
    )

    if df is None or df.empty:

        st.warning(
            "Aucune donnée disponible dans la base RC & SATISFACTION."
        )

        return

    if "Date" not in df.columns:

        st.warning(
            "La colonne Date n'est pas présente dans la base Réclamations."
        )

        return

    # ========================================================
    # DATES
    # ========================================================

    dates = pd.to_datetime(
        df["Date"],
        errors="coerce",
        dayfirst=True,
    ).dropna()

    if dates.empty:

        st.warning(
            "Aucune date exploitable dans la base Réclamations."
        )

        return

    dates_df = pd.DataFrame({
        "Date": dates
    })

    # ========================================================
    # FILTRES
    # ========================================================

    col1, col2 = st.columns(2)

    with col1:

        granularite = st.selectbox(
            "Granularité",
            GRANULARITES,
            index=2,
            key="reclamation_granularite",
        )

    periodes = construire_periodes(
        dates_df,
        granularite,
    )

    if not periodes:

        st.warning(
            "Aucune période disponible."
        )

        return

    labels = [
        periode.label
        for periode in periodes
    ]

    with col2:

        periode_label = st.selectbox(
            "Période",
            labels,
            index=len(labels) - 1,
            key="reclamation_periode",
        )

    periode = next(
        p
        for p in periodes
        if p.label == periode_label
    )

    periode_avant = periode_precedente(
        periode
    )

    # ========================================================
    # DONNEES
    # ========================================================

    df_actuel = _filtrer_periode(
        df,
        periode,
    )

    df_precedent = _filtrer_periode(
        df,
        periode_avant,
    )

    # ========================================================
    # PERIODE
    # ========================================================

    st.info(
        f"📅 **{periode.label}** : "
        f"{periode.debut.strftime('%d/%m/%Y')} → "
        f"{periode.fin.strftime('%d/%m/%Y')} "
        f"| Comparaison : **{periode_avant.label}**"
    )

    # ========================================================
    # KPI
    # ========================================================

    kpis_actuels = reclamation_kpis(
        df_actuel
    )

    kpis_precedents = {
        kpi["name"]: kpi
        for kpi in reclamation_kpis(
            df_precedent
        )
    }

    st.markdown(
        "### 🎯 Indicateurs Réclamations"
    )

    colonnes = st.columns(4)

    for i, kpi in enumerate(
        kpis_actuels
    ):

        precedent = kpis_precedents.get(
            kpi["name"]
        )

        valeur = kpi["value"]

        ancienne = (
            precedent["value"]
            if precedent
            else None
        )

        if valeur is None:

            affichage = "—"

        elif kpi["unit"] == "%":

            affichage = f"{valeur:.1f}%"

        else:

            affichage = (
                f"{valeur:,.1f}"
                .replace(",", " ")
            )

        delta = None

        if (
            valeur is not None
            and ancienne is not None
        ):

            ecart = valeur - ancienne

            if kpi["unit"] == "%":

                delta = f"{ecart:+.1f} pt"

            else:

                delta = (
                    f"{ecart:+,.1f}"
                    .replace(",", " ")
                )

        with colonnes[i % 4]:

            st.metric(
                kpi["name"],
                affichage,
                delta,
            )

    # ========================================================
    # GRAPHIQUES
    # ========================================================

    st.markdown("---")

    st.markdown(
        "### 📈 Évolution"
    )

    graph_cols = st.columns(2)

    with graph_cols[0]:
        afficher_tendance(
            df,
            granularite,
            reclamation_kpis,
            "Taux réclamations traitées dans le délai",
            couleur="#1769E0",
            key="reclamation_trend_mois",
        )

    with graph_cols[1]:
        afficher_tendance(
            df,
            granularite,
            reclamation_kpis,
            "Taux réclamations traitées dans les délais (base échue)",
            couleur="#E5484D",
            key="reclamation_trend_echue",
        )

    graph_cols2 = st.columns(2)

    with graph_cols2[0]:
        afficher_tendance(
            df,
            granularite,
            reclamation_kpis,
            "Taux réclamations \"Commissions\" traitées dans les délais",
            couleur="#D6A84F",
            key="reclamation_trend_commission",
        )

    with graph_cols2[1]:
        afficher_tendance(
            df,
            granularite,
            reclamation_kpis,
            "CSAT annuelle enquête",
            couleur="#20A464",
            key="reclamation_trend_csat",
        )

    # ========================================================
    # TABLEAU
    # ========================================================

    st.markdown("---")

    st.markdown(
        "### 📋 Données de la période"
    )

    st.caption(
        f"{len(df_actuel)} ligne(s) "
        f"pour la période sélectionnée."
    )

    if df_actuel.empty:

        st.info(
            "Aucune donnée pour cette période."
        )

    else:

        st.dataframe(
            df_actuel,
            use_container_width=True,
            height=400,
            key="reclamation_donnees_actuelles",
        )