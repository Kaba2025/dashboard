import streamlit as st
import pandas as pd

from kpi_dex import messagerie_kpis
from periods import (
    GRANULARITES,
    construire_periodes,
    periode_precedente,
)
from charts import afficher_tendance


def _filtrer_periode(df, periode):

    resultat = df.copy()

    if "Date" in resultat.columns:

        dates = pd.to_datetime(
            resultat["Date"],
            errors="coerce",
            dayfirst=True,
        ).dt.normalize()

        resultat = resultat.loc[
            dates.between(
                periode.debut,
                periode.fin,
            )
        ].copy()

    return resultat


def render(df):

    st.markdown("## 💬 Messagerie")

    st.caption(
        "Suivi des échanges clients par WhatsApp et courrier électronique."
    )

    if df is None or df.empty:

        st.warning(
            "Aucune donnée disponible dans la base Messagerie."
        )

        return

    if "Date" not in df.columns:

        st.warning(
            "La colonne Date n'est pas présente dans la base Messagerie."
        )

        return

    # ========================================================
    # DATES
    # ========================================================

    dates = pd.to_datetime(
        df["Date"],
        errors="coerce",
        dayfirst=True,
    ).dropna()

    if dates.empty:

        st.warning(
            "Aucune date exploitable dans la base Messagerie."
        )

        return

    dates_df = pd.DataFrame({
        "Date": dates
    })

    # ========================================================
    # FILTRES
    # ========================================================

    col1, col2 = st.columns(2)

    with col1:

        granularite = st.selectbox(
            "Granularité",
            GRANULARITES,
            index=2,
            key="messagerie_granularite",
        )

    periodes = construire_periodes(
        dates_df,
        granularite,
    )

    if not periodes:

        st.warning(
            "Aucune période disponible."
        )

        return

    labels = [
        periode.label
        for periode in periodes
    ]

    with col2:

        periode_label = st.selectbox(
            "Période",
            labels,
            index=len(labels) - 1,
            key="messagerie_periode",
        )

    periode = next(
        p
        for p in periodes
        if p.label == periode_label
    )

    periode_avant = periode_precedente(
        periode
    )

    # ========================================================
    # DONNEES
    # ========================================================

    df_actuel = _filtrer_periode(
        df,
        periode,
    )

    df_precedent = _filtrer_periode(
        df,
        periode_avant,
    )

    # ========================================================
    # PERIODE
    # ========================================================

    st.info(
        f"📅 **{periode.label}** : "
        f"{periode.debut.strftime('%d/%m/%Y')} → "
        f"{periode.fin.strftime('%d/%m/%Y')} "
        f"| Comparaison : **{periode_avant.label}**"
    )

    # ========================================================
    # KPI
    # ========================================================

    kpis_actuels = messagerie_kpis(
        df_actuel
    )

    kpis_precedents = {
        kpi["name"]: kpi
        for kpi in messagerie_kpis(
            df_precedent
        )
    }

    st.markdown(
        "### 🎯 Indicateurs Messagerie"
    )

    colonnes = st.columns(3)

    for i, kpi in enumerate(
        kpis_actuels
    ):

        precedent = kpis_precedents.get(
            kpi["name"]
        )

        valeur = kpi["value"]

        ancienne = (
            precedent["value"]
            if precedent
            else None
        )

        if valeur is None:

            affichage = "—"

        elif kpi["unit"] == "%":

            affichage = f"{valeur:.1f}%"

        else:

            affichage = (
                f"{valeur:,.1f}"
                .replace(",", " ")
            )

        delta = None

        if (
            valeur is not None
            and ancienne is not None
        ):

            ecart = valeur - ancienne

            if kpi["unit"] == "%":

                delta = f"{ecart:+.1f} pt"

            else:

                delta = (
                    f"{ecart:+,.1f}"
                    .replace(",", " ")
                )

        with colonnes[i % 3]:

            st.metric(
                kpi["name"],
                affichage,
                delta,
            )

    # ========================================================
    # GRAPHIQUES
    # ========================================================

    st.markdown("---")

    st.markdown(
        "### 📈 Évolution"
    )

    graph_cols = st.columns(3)

    with graph_cols[0]:
        afficher_tendance(
            df,
            granularite,
            messagerie_kpis,
            "Taux clôture WhatsApp",
            couleur="#20A464",
            key="messagerie_trend_whatsapp",
        )

    with graph_cols[1]:
        afficher_tendance(
            df,
            granularite,
            messagerie_kpis,
            "Taux clôture Mail",
            couleur="#1769E0",
            key="messagerie_trend_mail",
        )

    with graph_cols[2]:
        afficher_tendance(
            df,
            granularite,
            messagerie_kpis,
            "Taux de traitement Ecoute.ci",
            couleur="#D6A84F",
            key="messagerie_trend_ecoute",
        )

    # ========================================================
    # TABLEAU
    # ========================================================

    st.markdown("---")

    st.markdown(
        "### 📋 Données de la période"
    )

    if df_actuel.empty:

        st.info(
            "Aucune donnée pour cette période."
        )

    else:

        st.dataframe(
            df_actuel,
            use_container_width=True,
            height=400,
            key="messagerie_donnees_actuelles",
        )