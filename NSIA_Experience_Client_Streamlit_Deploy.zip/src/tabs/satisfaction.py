from __future__ import annotations

from collections import Counter
from dataclasses import dataclass
from typing import Optional

import numpy as np
import pandas as pd
import plotly.graph_objects as go
import streamlit as st

from settings import get_csat_barometre
from theme import (
    GOLD,
    BLUE_ACCENT,
    GREEN_ACCENT,
    PURPLE_ACCENT,
    NAVY_DARK,
    kpi_card,
    section,
)


# ============================================================
# CONFIGURATION
# ============================================================

OBJECTIF_SATISFACTION = 75.0
OBJECTIF_RECUEIL = 80.0
OBJECTIF_RECLAMATIONS = 100.0

ROUGE = "#EF4444"
ORANGE = "#F59E0B"
CYAN = "#38D9E8"
BLANC = "#FFFFFF"

GRILLE = "rgba(255,255,255,0.08)"
TEXTE = "#EAF0FA"
TEXTE_DOUX = "rgba(255,255,255,0.68)"
TEXTE_FAIBLE = "rgba(255,255,255,0.42)"


# ============================================================
# GRANULARITÉS
# ============================================================

GRANULARITES = [
    "Journalier",
    "Hebdomadaire",
    "Mensuel",
    "Bimestriel",
    "Trimestriel",
    "Semestriel",
    "Annuel",
]


# ============================================================
# STRUCTURE PÉRIODE
# ============================================================

@dataclass
class Periode:
    granularite: str
    debut: pd.Timestamp
    fin: pd.Timestamp
    label: str
    cle: str


# ============================================================
# UTILITAIRES GÉNÉRAUX
# ============================================================

def _prepare_dates(df: pd.DataFrame) -> pd.DataFrame:
    out = df.copy()

    if "Date" not in out.columns:
        return out

    out["Date"] = pd.to_datetime(
        out["Date"],
        errors="coerce",
        dayfirst=True,
    ).dt.normalize()

    return out.dropna(subset=["Date"]).copy()


def _num(df: pd.DataFrame, column: str) -> float:
    if column not in df.columns:
        return 0.0

    values = pd.to_numeric(
        df[column],
        errors="coerce",
    ).fillna(0)

    return float(values.sum())


def _ratio(
    numerateur: float,
    denominateur: float,
) -> Optional[float]:

    if denominateur is None:
        return None

    if denominateur <= 0:
        return None

    return numerateur / denominateur * 100.0


def _variation_pct(
    actuel: Optional[float],
    precedent: Optional[float],
) -> Optional[float]:

    if actuel is None or precedent is None:
        return None

    if pd.isna(actuel) or pd.isna(precedent):
        return None

    if precedent == 0:
        return None

    return (
        (float(actuel) - float(precedent))
        / abs(float(precedent))
        * 100.0
    )


def _fmt_nombre(value) -> str:
    if value is None or pd.isna(value):
        return "—"

    return f"{float(value):,.0f}".replace(",", " ")


def _fmt_pct(value) -> str:
    if value is None or pd.isna(value):
        return "—"

    return f"{float(value):.1f}%"


def _fmt_variation(value) -> str:
    if value is None or pd.isna(value):
        return "Pas de comparaison disponible"

    if abs(float(value)) < 0.05:
        return "0,0 % vs période précédente"

    return (
        f"{'+' if value > 0 else ''}"
        f"{float(value):.1f}% vs période précédente"
    ).replace(".", ",")


def _clean_text_series(
    df: pd.DataFrame,
    column: str,
) -> pd.Series:

    if column not in df.columns:
        return pd.Series(dtype="object")

    values = (
        df[column]
        .fillna("")
        .astype(str)
        .str.replace(r"\s+", " ", regex=True)
        .str.strip()
    )

    values = values[
        ~values.str.lower().isin(
            [
                "",
                "nan",
                "none",
                "n/a",
                "na",
                "-",
                "—",
            ]
        )
    ]

    return values


# ============================================================
# CONSTRUCTION DES PÉRIODES
# ============================================================

MOIS_FR = {
    1: "Janvier",
    2: "Février",
    3: "Mars",
    4: "Avril",
    5: "Mai",
    6: "Juin",
    7: "Juillet",
    8: "Août",
    9: "Septembre",
    10: "Octobre",
    11: "Novembre",
    12: "Décembre",
}


def _nom_mois(mois: int) -> str:
    return MOIS_FR.get(mois, str(mois))


def _construire_periodes(
    df_annee: pd.DataFrame,
    granularite: str,
) -> list[Periode]:

    if df_annee.empty or "Date" not in df_annee.columns:
        return []

    dates = pd.to_datetime(
        df_annee["Date"],
        errors="coerce",
    ).dropna()

    if dates.empty:
        return []

    debut_annee = pd.Timestamp(
        year=int(dates.dt.year.iloc[0]),
        month=1,
        day=1,
    )

    fin_annee = pd.Timestamp(
        year=int(dates.dt.year.iloc[0]),
        month=12,
        day=31,
    )

    resultats: list[Periode] = []

    # --------------------------------------------------------
    # JOURNALIER
    # --------------------------------------------------------

    if granularite == "Journalier":

        dates_uniques = sorted(
            dates.dt.normalize().unique()
        )

        for date in dates_uniques:

            d = pd.Timestamp(date)

            resultats.append(
                Periode(
                    "Journalier",
                    d,
                    d,
                    d.strftime("%d/%m/%Y"),
                    d.strftime("%Y-%m-%d"),
                )
            )

        return resultats

    # --------------------------------------------------------
    # HEBDOMADAIRE
    # --------------------------------------------------------

    if granularite == "Hebdomadaire":

        courant = debut_annee

        while courant <= fin_annee:

            fin = min(
                courant + pd.Timedelta(days=6),
                fin_annee,
            )

            semaine = int(
                courant.isocalendar().week
            )

            resultats.append(
                Periode(
                    "Hebdomadaire",
                    courant,
                    fin,
                    (
                        f"Semaine {semaine} — "
                        f"{courant.strftime('%d/%m')} "
                        f"au {fin.strftime('%d/%m')}"
                    ),
                    f"{courant.year}-S{semaine:02d}",
                )
            )

            courant = fin + pd.Timedelta(days=1)

        return [
            p
            for p in resultats
            if (
                df_annee["Date"].between(
                    p.debut,
                    p.fin,
                ).any()
            )
        ]

    # --------------------------------------------------------
    # MENSUEL
    # --------------------------------------------------------

    if granularite == "Mensuel":

        courant = debut_annee

        while courant <= fin_annee:

            fin = courant + pd.offsets.MonthEnd(0)

            resultats.append(
                Periode(
                    "Mensuel",
                    courant,
                    fin,
                    _nom_mois(courant.month),
                    courant.strftime("%Y-%m"),
                )
            )

            courant = (
                fin + pd.Timedelta(days=1)
            ).normalize()

        return [
            p
            for p in resultats
            if (
                df_annee["Date"].between(
                    p.debut,
                    p.fin,
                ).any()
            )
        ]

    # --------------------------------------------------------
    # BIMENSUEL
    # --------------------------------------------------------

    if granularite == "Bimestriel":

        for numero in range(6):

            mois_debut = 1 + numero * 2

            debut = pd.Timestamp(
                year=debut_annee.year,
                month=mois_debut,
                day=1,
            )

            fin = (
                debut
                + pd.DateOffset(months=2)
                - pd.Timedelta(days=1)
            )

            resultats.append(
                Periode(
                    "Bimestriel",
                    debut,
                    fin,
                    f"Bimestre {numero + 1}",
                    f"{debut.year}-B{numero + 1}",
                )
            )

        return [
            p
            for p in resultats
            if (
                df_annee["Date"].between(
                    p.debut,
                    p.fin,
                ).any()
            )
        ]

    # --------------------------------------------------------
    # TRIMESTRIEL
    # --------------------------------------------------------

    if granularite == "Trimestriel":

        for trimestre in range(1, 5):

            mois_debut = (
                1 + (trimestre - 1) * 3
            )

            debut = pd.Timestamp(
                year=debut_annee.year,
                month=mois_debut,
                day=1,
            )

            fin = (
                debut
                + pd.DateOffset(months=3)
                - pd.Timedelta(days=1)
            )

            resultats.append(
                Periode(
                    "Trimestriel",
                    debut,
                    fin,
                    f"Trimestre {trimestre}",
                    f"{debut.year}-T{trimestre}",
                )
            )

        return [
            p
            for p in resultats
            if (
                df_annee["Date"].between(
                    p.debut,
                    p.fin,
                ).any()
            )
        ]

    # --------------------------------------------------------
    # SEMESTRIEL
    # --------------------------------------------------------

    if granularite == "Semestriel":

        for semestre in range(1, 3):

            mois_debut = (
                1 if semestre == 1 else 7
            )

            debut = pd.Timestamp(
                year=debut_annee.year,
                month=mois_debut,
                day=1,
            )

            fin = (
                debut
                + pd.DateOffset(months=6)
                - pd.Timedelta(days=1)
            )

            resultats.append(
                Periode(
                    "Semestriel",
                    debut,
                    fin,
                    f"Semestre {semestre}",
                    f"{debut.year}-S{semestre}",
                )
            )

        return [
            p
            for p in resultats
            if (
                df_annee["Date"].between(
                    p.debut,
                    p.fin,
                ).any()
            )
        ]

    # --------------------------------------------------------
    # ANNUEL
    # --------------------------------------------------------

    return [
        Periode(
            "Annuel",
            debut_annee,
            fin_annee,
            f"Année {debut_annee.year}",
            str(debut_annee.year),
        )
    ]


# ============================================================
# PÉRIODE PRÉCÉDENTE
# ============================================================

def _periode_precedente(
    periode: Periode,
) -> Periode:

    if periode.granularite == "Journalier":

        debut = (
            periode.debut
            - pd.Timedelta(days=1)
        )

        return Periode(
            "Journalier",
            debut,
            debut,
            debut.strftime("%d/%m/%Y"),
            debut.strftime("%Y-%m-%d"),
        )

    if periode.granularite == "Hebdomadaire":

        debut = (
            periode.debut
            - pd.Timedelta(days=7)
        )

        fin = (
            periode.fin
            - pd.Timedelta(days=7)
        )

        semaine = int(
            debut.isocalendar().week
        )

        return Periode(
            "Hebdomadaire",
            debut,
            fin,
            (
                f"Semaine {semaine} — "
                f"{debut.strftime('%d/%m')} "
                f"au {fin.strftime('%d/%m')}"
            ),
            f"{debut.year}-S{semaine:02d}",
        )

    if periode.granularite == "Mensuel":

        precedent = (
            periode.debut
            - pd.DateOffset(months=1)
        )

        fin = precedent + pd.offsets.MonthEnd(0)

        return Periode(
            "Mensuel",
            precedent,
            fin,
            _nom_mois(precedent.month),
            precedent.strftime("%Y-%m"),
        )

    if periode.granularite == "Bimestriel":

        debut = (
            periode.debut
            - pd.DateOffset(months=2)
        )

        fin = (
            debut
            + pd.DateOffset(months=2)
            - pd.Timedelta(days=1)
        )

        numero = (
            (debut.month - 1) // 2
        ) + 1

        return Periode(
            "Bimestriel",
            debut,
            fin,
            f"Bimestre {numero}",
            f"{debut.year}-B{numero}",
        )

    if periode.granularite == "Trimestriel":

        debut = (
            periode.debut
            - pd.DateOffset(months=3)
        )

        fin = (
            debut
            + pd.DateOffset(months=3)
            - pd.Timedelta(days=1)
        )

        numero = (
            (debut.month - 1) // 3
        ) + 1

        return Periode(
            "Trimestriel",
            debut,
            fin,
            f"Trimestre {numero}",
            f"{debut.year}-T{numero}",
        )

    if periode.granularite == "Semestriel":

        debut = (
            periode.debut
            - pd.DateOffset(months=6)
        )

        fin = (
            debut
            + pd.DateOffset(months=6)
            - pd.Timedelta(days=1)
        )

        numero = (
            1
            if debut.month == 1
            else 2
        )

        return Periode(
            "Semestriel",
            debut,
            fin,
            f"Semestre {numero}",
            f"{debut.year}-S{numero}",
        )

    debut = (
        periode.debut
        - pd.DateOffset(years=1)
    )

    fin = (
        debut
        + pd.DateOffset(years=1)
        - pd.Timedelta(days=1)
    )

    return Periode(
        "Annuel",
        debut,
        fin,
        f"Année {debut.year}",
        str(debut.year),
    )


# ============================================================
# FILTRE DE DATE
# ============================================================

def _filtrer_periode(
    df: pd.DataFrame,
    periode: Periode,
) -> pd.DataFrame:

    if df.empty:
        return df.copy()

    return df.loc[
        df["Date"].between(
            periode.debut,
            periode.fin,
            inclusive="both",
        )
    ].copy()


# ============================================================
# EXTRACTION DES RÉCLAMATIONS
# ============================================================

def _derniere_valeur_cumulative(
    df: pd.DataFrame,
    colonne: str,
) -> float:

    if colonne not in df.columns or df.empty:
        return 0.0

    temp = df[
        [
            "Date",
            colonne,
        ]
    ].copy()

    temp[colonne] = pd.to_numeric(
        temp[colonne],
        errors="coerce",
    )

    temp = temp.dropna(
        subset=[colonne]
    ).sort_values("Date")

    if temp.empty:
        return 0.0

    return float(
        temp.iloc[-1][colonne]
    )


# ============================================================
# KPI PRINCIPAUX
# ============================================================

def _kpi_periode(
    df: pd.DataFrame,
) -> dict:

    recueil = _num(
        df,
        "Recueil de satisfaction",
    )

    satisfaits = _num(
        df,
        "Clients satisfaits",
    )

    clients_recus = _num(
        df,
        "Total clients reçus",
    )

    recla_mois_recues = _num(
        df,
        "Réclamations MOIS reçues",
    )

    recla_mois_traitees = _num(
        df,
        "Réclamations MOIS traitées dans les délais",
    )

    taux_satisfaction = _ratio(
        satisfaits,
        recueil,
    )

    taux_recueil = _ratio(
        recueil,
        clients_recus,
    )

    taux_recla_temps = _ratio(
        recla_mois_traitees,
        recla_mois_recues,
    )

    try:
        grande_enquete = (
            float(get_csat_barometre())
            * 100.0
        )
    except Exception:
        grande_enquete = 68.0

    # --------------------------------------------------------
    # SATISFACTION GLOBALE
    # --------------------------------------------------------

    if (
        taux_satisfaction is not None
        and taux_recla_temps is not None
    ):

        satisfaction_globale = (
            grande_enquete * 0.50
            + taux_satisfaction * 0.25
            + taux_recla_temps * 0.25
        )

    elif taux_satisfaction is not None:

        satisfaction_globale = (
            grande_enquete * 0.50
            + taux_satisfaction * 0.50
        )

    else:

        satisfaction_globale = None

    # --------------------------------------------------------
    # COMMENTAIRES
    # --------------------------------------------------------

    cp = len(
        _clean_text_series(
            df,
            "Contre Performance",
        )
    )

    initiatives = len(
        _clean_text_series(
            df,
            "Initiative",
        )
    )

    observations = len(
        _clean_text_series(
            df,
            "Observations",
        )
    )

    # --------------------------------------------------------
    # RÉCLAMATIONS ANNÉE
    # --------------------------------------------------------

    recla_annee_recues = (
        _derniere_valeur_cumulative(
            df,
            "Réclamations ANNÉE reçues",
        )
    )

    recla_annee_traitees = (
        _derniere_valeur_cumulative(
            df,
            "Réclamations ANNÉE traitées dans les délais",
        )
    )

    taux_recla_annee = _ratio(
        recla_annee_traitees,
        recla_annee_recues,
    )

    # --------------------------------------------------------
    # COMMISSIONS
    # --------------------------------------------------------

    commission_recues = (
        _derniere_valeur_cumulative(
            df,
            "Réclamations COMMISSION reçues",
        )
    )

    commission_traitees = (
        _derniere_valeur_cumulative(
            df,
            "Réclamations COMMISSION traitées dans les délais",
        )
    )

    taux_commission = _ratio(
        commission_traitees,
        commission_recues,
    )

    annulations_commission = (
        _derniere_valeur_cumulative(
            df,
            "Réclamations ANNULATION COMMISSION reçues",
        )
    )

    mises_a_jour = _num(
        df,
        "Nombre de mise à jour journalière",
    )

    return {
        "satisfaction_globale": satisfaction_globale,
        "taux_satisfaction": taux_satisfaction,
        "taux_recueil": taux_recueil,
        "taux_recla_temps": taux_recla_temps,
        "grande_enquete": grande_enquete,

        "clients_recus": clients_recus,
        "recueil": recueil,
        "clients_satisfaits": satisfaits,

        "reclamations_recues": recla_mois_recues,
        "reclamations_traitees": recla_mois_traitees,

        "cp": cp,
        "initiatives": initiatives,
        "observations": observations,

        "recla_annee_recues": recla_annee_recues,
        "recla_annee_traitees": recla_annee_traitees,
        "taux_recla_annee": taux_recla_annee,

        "commission_recues": commission_recues,
        "commission_traitees": commission_traitees,
        "taux_commission": taux_commission,
        "annulations_commission": annulations_commission,

        "mises_a_jour": mises_a_jour,
    }


# ============================================================
# STATUT KPI
# ============================================================

def _statut(
    valeur: Optional[float],
    objectif: float,
) -> str:

    if valeur is None or pd.isna(valeur):
        return "neutral"

    if valeur >= objectif:
        return "good"

    if valeur >= objectif * 0.90:
        return "warn"

    return "bad"


# ============================================================
# CARTE KPI AVEC VARIATION
# ============================================================

def _render_kpi(
    icon: str,
    label: str,
    value,
    previous,
    objectif: Optional[float] = None,
    subtitle: str = "",
    inverse: bool = False,
):

    variation = _variation_pct(
        value,
        previous,
    )

    if objectif is not None:
        status = _statut(
            value,
            objectif,
        )
    else:
        status = "neutral"

    if inverse and value is not None:

        if value <= 0:
            status = "good"
        elif value > 0:
            status = "bad"

    if variation is None:
        comparaison = (
            "Pas de comparaison disponible"
        )
    else:

        signe = "+" if variation > 0 else ""

        comparaison = (
            f"{signe}{variation:.1f}% "
            "vs période précédente"
        ).replace(".", ",")

    description = comparaison

    if subtitle:
        description += f" · {subtitle}"

    if isinstance(value, (float, int)):

        if objectif is not None:
            valeur_affichee = _fmt_pct(
                value
            )
        else:
            valeur_affichee = _fmt_nombre(
                value
            )

    else:
        valeur_affichee = "—"

    kpi_card(
        icon,
        label,
        valeur_affichee,
        description,
        status,
    )


# ============================================================
# EN-TÊTE DE LA PAGE
# ============================================================

def _inject_page_css():

    st.markdown(
        """
        <style>

        .satisfaction-hero {
            padding: 1.45rem 1.7rem;
            margin-bottom: 1rem;
            border-radius: 20px;
            background:
                linear-gradient(
                    135deg,
                    rgba(24,44,80,0.98),
                    rgba(8,20,38,0.98)
                );
            border:
                1px solid
                rgba(212,175,55,0.18);
            box-shadow:
                0 12px 40px
                rgba(0,0,0,0.22);
        }

        .satisfaction-title {
            color: #FFFFFF;
            font-size: 1.65rem;
            font-weight: 850;
            letter-spacing: 0.01em;
        }

        .satisfaction-subtitle {
            color:
                rgba(255,255,255,0.58);
            font-size: 0.84rem;
            margin-top: 4px;
        }

        .satisfaction-context {
            margin-top: 1rem;
            padding: 10px 15px;
            border-radius: 12px;
            background:
                rgba(255,255,255,0.035);
            border:
                1px solid
                rgba(255,255,255,0.07);
            color:
                rgba(255,255,255,0.62);
            font-size: 0.72rem;
        }

        .pilotage-box {
            padding: 15px 17px;
            border-radius: 16px;
            background:
                linear-gradient(
                    135deg,
                    rgba(212,175,55,0.09),
                    rgba(255,255,255,0.025)
                );
            border:
                1px solid
                rgba(212,175,55,0.13);
        }

        .pilotage-title {
            color: #FFFFFF;
            font-weight: 800;
            font-size: 0.78rem;
            letter-spacing: 0.06em;
        }

        .pilotage-text {
            color:
                rgba(255,255,255,0.62);
            font-size: 0.74rem;
            margin-top: 5px;
            line-height: 1.5;
        }

        .insight-card {
            padding: 18px;
            border-radius: 16px;
            background:
                linear-gradient(
                    135deg,
                    rgba(22,42,80,0.92),
                    rgba(13,29,53,0.92)
                );
            border:
                1px solid
                rgba(255,255,255,0.07);
            margin-bottom: 10px;
        }

        .insight-title {
            color: #D4AF37;
            font-size: 0.72rem;
            font-weight: 850;
            letter-spacing: 0.09em;
        }

        .insight-text {
            color:
                rgba(255,255,255,0.76);
            font-size: 0.82rem;
            line-height: 1.55;
            margin-top: 8px;
        }

        .alert-item {
            padding: 11px 13px;
            border-radius: 11px;
            margin-bottom: 7px;
            background:
                rgba(255,255,255,0.035);
            border-left:
                3px solid #D4AF37;
        }

        .alert-item strong {
            color: #FFFFFF;
        }

        .alert-item span {
            color:
                rgba(255,255,255,0.62);
        }

        </style>
        """,
        unsafe_allow_html=True,
    )


# ============================================================
# TITRE
# ============================================================

def _render_header(
    annee: int,
    periode: Periode,
):

    st.markdown(
        f"""
        <div class="satisfaction-hero">

            <div class="satisfaction-title">
                😊 SATISFACTION
            </div>

            <div class="satisfaction-subtitle">
                Pilotage de la satisfaction client,
                du recueil et du traitement des réclamations
            </div>

            <div class="satisfaction-context">
                ANALYSE ACTIVE ·
                {periode.granularite.upper()}
                ·
                {annee}
                ·
                {periode.label}
            </div>

        </div>
        """,
        unsafe_allow_html=True,
    )


# ============================================================
# ÉVOLUTION DES TAUX
# ============================================================

def _donnees_evolution_taux(
    df_annee: pd.DataFrame,
    granularite: str,
):

    periodes = _construire_periodes(
        df_annee,
        granularite,
    )

    labels = []

    satisfaction_globale = []
    satisfaction = []
    recueil = []
    reclamations = []

    for periode in periodes:

        df_p = _filtrer_periode(
            df_annee,
            periode,
        )

        k = _kpi_periode(df_p)

        labels.append(
            periode.label
        )

        satisfaction_globale.append(
            k["satisfaction_globale"]
        )

        satisfaction.append(
            k["taux_satisfaction"]
        )

        recueil.append(
            k["taux_recueil"]
        )

        reclamations.append(
            k["taux_recla_temps"]
        )

    return (
        labels,
        satisfaction_globale,
        satisfaction,
        recueil,
        reclamations,
    )


def _graphique_evolution_taux(
    df_annee: pd.DataFrame,
    granularite: str,
    annee: int,
):

    (
        labels,
        globale,
        satisfaction,
        recueil,
        reclamations,
    ) = _donnees_evolution_taux(
        df_annee,
        granularite,
    )

    if not labels:
        st.info(
            "Aucune donnée disponible pour l'évolution."
        )
        return

    fig = go.Figure()

    series = [
        (
            "Satisfaction globale",
            globale,
            GREEN_ACCENT,
            4,
        ),
        (
            "Taux de satisfaction",
            satisfaction,
            BLUE_ACCENT,
            3,
        ),
        (
            "Taux de recueil",
            recueil,
            GOLD,
            3,
        ),
        (
            "Réclamations traitées dans les délais",
            reclamations,
            PURPLE_ACCENT,
            3,
        ),
    ]

    for nom, valeurs, couleur, largeur in series:

        fig.add_trace(
            go.Scatter(
                x=labels,
                y=valeurs,
                mode="lines+markers",
                name=nom,
                connectgaps=False,
                line=dict(
                    color=couleur,
                    width=largeur,
                    shape="spline",
                ),
                marker=dict(
                    size=7,
                    color=couleur,
                    line=dict(
                        width=1,
                        color=BLANC,
                    ),
                ),
                hovertemplate=(
                    f"<b>{nom}</b>"
                    "<br>%{x}"
                    "<br><b>%{y:.1f}%</b>"
                    "<extra></extra>"
                ),
            )
        )

    # Objectifs
    fig.add_hline(
        y=OBJECTIF_SATISFACTION,
        line_dash="dot",
        line_width=1.2,
        line_color="rgba(255,255,255,0.30)",
        annotation_text="Objectif satisfaction 75 %",
        annotation_position="top left",
    )

    fig.update_layout(
        height=430,
        margin=dict(
            l=15,
            r=15,
            t=35,
            b=20,
        ),
        paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor=NAVY_DARK,
        font=dict(
            family="Inter, Arial",
            color=TEXTE,
        ),
        hovermode="x unified",
        legend=dict(
            orientation="h",
            yanchor="bottom",
            y=1.01,
            xanchor="left",
            x=0,
            font=dict(size=10),
        ),
        xaxis=dict(
            showgrid=False,
            zeroline=False,
            tickfont=dict(size=10),
            rangeslider=dict(
                visible=len(labels) > 12
            ),
        ),
        yaxis=dict(
            range=[0, 105],
            ticksuffix="%",
            showgrid=True,
            gridcolor=GRILLE,
            zeroline=False,
            tickfont=dict(size=10),
        ),
    )

    st.plotly_chart(
        fig,
        use_container_width=True,
        config={
            "displayModeBar": True,
            "responsive": True,
        },
        key=f"satisfaction_taux_{annee}_{granularite}",
    )


# ============================================================
# ÉVOLUTION DES VOLUMES
# ============================================================

def _graphique_volumes(
    df_annee: pd.DataFrame,
    granularite: str,
    annee: int,
):

    periodes = _construire_periodes(
        df_annee,
        granularite,
    )

    if not periodes:
        return

    labels = []
    clients = []
    reponses = []
    satisfaits = []

    for periode in periodes:

        df_p = _filtrer_periode(
            df_annee,
            periode,
        )

        k = _kpi_periode(df_p)

        labels.append(
            periode.label
        )

        clients.append(
            k["clients_recus"]
        )

        reponses.append(
            k["recueil"]
        )

        satisfaits.append(
            k["clients_satisfaits"]
        )

    fig = go.Figure()

    fig.add_trace(
        go.Bar(
            x=labels,
            y=clients,
            name="Clients reçus",
            marker_color=BLUE_ACCENT,
            opacity=0.55,
            hovertemplate=(
                "<b>%{x}</b>"
                "<br>Clients reçus : "
                "<b>%{y:,.0f}</b>"
                "<extra></extra>"
            ),
        )
    )

    fig.add_trace(
        go.Scatter(
            x=labels,
            y=reponses,
            name="Réponses recueillies",
            mode="lines+markers",
            line=dict(
                color=GOLD,
                width=3,
                shape="spline",
            ),
            marker=dict(
                size=7,
                color=GOLD,
            ),
            hovertemplate=(
                "<b>%{x}</b>"
                "<br>Réponses recueillies : "
                "<b>%{y:,.0f}</b>"
                "<extra></extra>"
            ),
        )
    )

    fig.add_trace(
        go.Scatter(
            x=labels,
            y=satisfaits,
            name="Clients satisfaits",
            mode="lines+markers",
            line=dict(
                color=GREEN_ACCENT,
                width=3,
                shape="spline",
            ),
            marker=dict(
                size=7,
                color=GREEN_ACCENT,
            ),
            hovertemplate=(
                "<b>%{x}</b>"
                "<br>Clients satisfaits : "
                "<b>%{y:,.0f}</b>"
                "<extra></extra>"
            ),
        )
    )

    fig.update_layout(
        height=390,
        margin=dict(
            l=15,
            r=15,
            t=35,
            b=20,
        ),
        paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor=NAVY_DARK,
        font=dict(
            family="Inter, Arial",
            color=TEXTE,
        ),
        hovermode="x unified",
        legend=dict(
            orientation="h",
            yanchor="bottom",
            y=1.01,
            xanchor="left",
            x=0,
        ),
        xaxis=dict(
            showgrid=False,
            tickfont=dict(size=10),
            rangeslider=dict(
                visible=len(labels) > 12
            ),
        ),
        yaxis=dict(
            showgrid=True,
            gridcolor=GRILLE,
            zeroline=False,
        ),
    )

    st.plotly_chart(
        fig,
        use_container_width=True,
        config={
            "displayModeBar": True,
            "responsive": True,
        },
        key=f"satisfaction_volumes_{annee}_{granularite}",
    )


# ============================================================
# ÉVOLUTION DES RÉCLAMATIONS
# ============================================================

def _graphique_reclamations(
    df_annee: pd.DataFrame,
    granularite: str,
):

    periodes = _construire_periodes(
        df_annee,
        granularite,
    )

    if not periodes:
        return

    labels = []
    recues = []
    traitees = []

    for periode in periodes:

        df_p = _filtrer_periode(
            df_annee,
            periode,
        )

        k = _kpi_periode(df_p)

        labels.append(
            periode.label
        )

        recues.append(
            k["reclamations_recues"]
        )

        traitees.append(
            k["reclamations_traitees"]
        )

    fig = go.Figure()

    fig.add_trace(
        go.Bar(
            x=labels,
            y=recues,
            name="Réclamations reçues",
            marker_color=ROUGE,
            opacity=0.55,
            hovertemplate=(
                "<b>%{x}</b>"
                "<br>Réclamations reçues : "
                "<b>%{y:,.0f}</b>"
                "<extra></extra>"
            ),
        )
    )

    fig.add_trace(
        go.Scatter(
            x=labels,
            y=traitees,
            name="Réclamations traitées dans les délais",
            mode="lines+markers",
            line=dict(
                color=GREEN_ACCENT,
                width=3,
            ),
            marker=dict(
                size=7,
            ),
            hovertemplate=(
                "<b>%{x}</b>"
                "<br>Traitées dans les délais : "
                "<b>%{y:,.0f}</b>"
                "<extra></extra>"
            ),
        )
    )

    fig.update_layout(
        height=360,
        margin=dict(
            l=15,
            r=15,
            t=25,
            b=20,
        ),
        paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor=NAVY_DARK,
        font=dict(
            family="Inter, Arial",
            color=TEXTE,
        ),
        hovermode="x unified",
        legend=dict(
            orientation="h",
            yanchor="bottom",
            y=1.01,
            xanchor="left",
            x=0,
        ),
        xaxis=dict(
            showgrid=False,
        ),
        yaxis=dict(
            showgrid=True,
            gridcolor=GRILLE,
            zeroline=False,
        ),
    )

    st.plotly_chart(
        fig,
        use_container_width=True,
        config={
            "displayModeBar": True,
            "responsive": True,
        },
        key=f"satisfaction_reclamations_{granularite}",
    )


# ============================================================
# ANALYSE DES COMMENTAIRES
# ============================================================

def _top_commentaires(
    df: pd.DataFrame,
    colonne: str,
    maximum: int = 8,
) -> pd.DataFrame:

    values = _clean_text_series(
        df,
        colonne,
    )

    if values.empty:
        return pd.DataFrame(
            columns=[
                "Libellé",
                "Nombre",
            ]
        )

    counts = (
        values
        .value_counts()
        .head(maximum)
        .rename_axis("Libellé")
        .reset_index(name="Nombre")
    )

    return counts


def _graphique_commentaires(
    df: pd.DataFrame,
    colonne: str,
    titre: str,
    couleur: str,
):

    data = _top_commentaires(
        df,
        colonne,
        8,
    )

    if data.empty:

        st.info(
            f"Aucun élément renseigné dans « {colonne} » "
            "pour la période sélectionnée."
        )

        return

    data = data.sort_values(
        "Nombre",
        ascending=True,
    )

    fig = go.Figure()

    fig.add_trace(
        go.Bar(
            x=data["Nombre"],
            y=data["Libellé"],
            orientation="h",
            marker_color=couleur,
            opacity=0.85,
            text=data["Nombre"],
            textposition="outside",
            hovertemplate=(
                "<b>%{y}</b>"
                "<br>Nombre de signalements : "
                "<b>%{x}</b>"
                "<extra></extra>"
            ),
        )
    )

    hauteur = max(
        280,
        len(data) * 46,
    )

    fig.update_layout(
        height=hauteur,
        margin=dict(
            l=10,
            r=40,
            t=15,
            b=15,
        ),
        paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor=NAVY_DARK,
        font=dict(
            family="Inter, Arial",
            color=TEXTE,
        ),
        xaxis=dict(
            showgrid=True,
            gridcolor=GRILLE,
            zeroline=False,
        ),
        yaxis=dict(
            showgrid=False,
            zeroline=False,
        ),
        showlegend=False,
    )

    st.plotly_chart(
        fig,
        use_container_width=True,
        config={
            "displayModeBar": True,
            "responsive": True,
        },
        key=f"commentaires_{colonne}_{len(data)}",
    )


# ============================================================
# ÉVOLUTION CONTRE-PERFORMANCES
# ============================================================

def _graphique_evolution_commentaire(
    df_annee: pd.DataFrame,
    granularite: str,
    colonne: str,
    couleur: str,
    cle: str,
):

    periodes = _construire_periodes(
        df_annee,
        granularite,
    )

    labels = []
    valeurs = []

    for periode in periodes:

        df_p = _filtrer_periode(
            df_annee,
            periode,
        )

        valeurs_texte = _clean_text_series(
            df_p,
            colonne,
        )

        labels.append(
            periode.label
        )

        valeurs.append(
            len(valeurs_texte)
        )

    if not labels:
        return

    fig = go.Figure()

    fig.add_trace(
        go.Scatter(
            x=labels,
            y=valeurs,
            mode="lines+markers",
            line=dict(
                color=couleur,
                width=3,
                shape="spline",
            ),
            marker=dict(
                size=7,
                color=couleur,
            ),
            fill="tozeroy",
            fillcolor=(
                "rgba(239,68,68,0.07)"
                if cle == "cp"
                else "rgba(212,175,55,0.07)"
            ),
            hovertemplate=(
                "<b>%{x}</b>"
                "<br>Signalements : "
                "<b>%{y}</b>"
                "<extra></extra>"
            ),
        )
    )

    fig.update_layout(
        height=320,
        margin=dict(
            l=15,
            r=15,
            t=15,
            b=15,
        ),
        paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor=NAVY_DARK,
        font=dict(
            family="Inter, Arial",
            color=TEXTE,
        ),
        xaxis=dict(
            showgrid=False,
            rangeslider=dict(
                visible=len(labels) > 12
            ),
        ),
        yaxis=dict(
            showgrid=True,
            gridcolor=GRILLE,
            zeroline=False,
        ),
        showlegend=False,
    )

    st.plotly_chart(
        fig,
        use_container_width=True,
        config={
            "displayModeBar": True,
            "responsive": True,
        },
        key=f"evolution_{cle}_{granularite}",
    )


# ============================================================
# RÉCLAMATIONS — TABLEAU DE PILOTAGE
# ============================================================

def _render_tableau_reclamations(
    k: dict,
):

    lignes = [
        {
            "Indicateur": "Réclamations du mois reçues",
            "Valeur": _fmt_nombre(
                k["reclamations_recues"]
            ),
        },
        {
            "Indicateur": "Réclamations du mois traitées dans les délais",
            "Valeur": _fmt_nombre(
                k["reclamations_traitees"]
            ),
        },
        {
            "Indicateur": "Taux de traitement dans les délais — mois",
            "Valeur": _fmt_pct(
                k["taux_recla_temps"]
            ),
        },
        {
            "Indicateur": "Réclamations de l'année reçues",
            "Valeur": _fmt_nombre(
                k["recla_annee_recues"]
            ),
        },
        {
            "Indicateur": "Réclamations de l'année traitées dans les délais",
            "Valeur": _fmt_nombre(
                k["recla_annee_traitees"]
            ),
        },
        {
            "Indicateur": "Taux de traitement dans les délais — année",
            "Valeur": _fmt_pct(
                k["taux_recla_annee"]
            ),
        },
        {
            "Indicateur": "Réclamations Commission reçues",
            "Valeur": _fmt_nombre(
                k["commission_recues"]
            ),
        },
        {
            "Indicateur": "Réclamations Commission traitées dans les délais",
            "Valeur": _fmt_nombre(
                k["commission_traitees"]
            ),
        },
        {
            "Indicateur": "Taux Commission traité dans les délais",
            "Valeur": _fmt_pct(
                k["taux_commission"]
            ),
        },
        {
            "Indicateur": "Annulations Commission reçues",
            "Valeur": _fmt_nombre(
                k["annulations_commission"]
            ),
        },
    ]

    tableau = pd.DataFrame(lignes)

    st.dataframe(
        tableau,
        use_container_width=True,
        hide_index=True,
        height=410,
        column_config={
            "Indicateur": st.column_config.TextColumn(
                "Indicateur",
                width="large",
            ),
            "Valeur": st.column_config.TextColumn(
                "Valeur",
                width="medium",
            ),
        },
        key="satisfaction_tableau_reclamations",
    )


# ============================================================
# OBSERVATIONS TERRAIN
# ============================================================

def _render_observations(
    df: pd.DataFrame,
):

    values = _clean_text_series(
        df,
        "Observations",
    )

    if values.empty:

        st.info(
            "Aucune observation renseignée "
            "pour la période sélectionnée."
        )

        return

    counts = Counter(
        values.tolist()
    )

    principaux = (
        counts
        .most_common(8)
    )

    for texte, nombre in principaux:

        suffixe = (
            f"{nombre} occurrences"
            if nombre > 1
            else "1 occurrence"
        )

        st.markdown(
            f"""
            <div class="alert-item">
                <strong>{texte}</strong><br>
                <span>{suffixe}</span>
            </div>
            """,
            unsafe_allow_html=True,
        )

    with st.expander(
        "Voir les observations détaillées",
        expanded=False,
    ):

        for texte in (
            values
            .tail(30)
            .tolist()[::-1]
        ):

            st.write(
                f"— {texte}"
            )


# ============================================================
# ANALYSE DÉCISIONNELLE
# ============================================================

def _render_analyse_decisionnelle(
    k: dict,
    k_precedent: dict,
):

    alertes = []
    positifs = []
    actions = []

    # --------------------------------------------------------
    # SATISFACTION
    # --------------------------------------------------------

    if (
        k["taux_satisfaction"] is not None
        and k["taux_satisfaction"]
        < OBJECTIF_SATISFACTION
    ):

        ecart = (
            OBJECTIF_SATISFACTION
            - k["taux_satisfaction"]
        )

        alertes.append(
            (
                "Satisfaction sous la cible",
                f"Le taux de satisfaction est de "
                f"{_fmt_pct(k['taux_satisfaction'])}, "
                f"soit {ecart:.1f} point(s) sous "
                f"la cible de 75 %."
            )
        )

        actions.append(
            "Analyser les principales causes "
            "d'insatisfaction et suivre leur évolution."
        )

    elif k["taux_satisfaction"] is not None:

        positifs.append(
            (
                "Satisfaction conforme à la cible",
                f"Le taux atteint "
                f"{_fmt_pct(k['taux_satisfaction'])}."
            )
        )

    # --------------------------------------------------------
    # RECUEIL
    # --------------------------------------------------------

    if (
        k["taux_recueil"] is not None
        and k["taux_recueil"]
        < OBJECTIF_RECUEIL
    ):

        alertes.append(
            (
                "Recueil sous la cible",
                f"Le taux de recueil est de "
                f"{_fmt_pct(k['taux_recueil'])} "
                f"contre une cible de 80 %."
            )
        )

        actions.append(
            "Renforcer le recueil des réponses "
            "auprès des clients non répondants."
        )

    # --------------------------------------------------------
    # RÉCLAMATIONS
    # --------------------------------------------------------

    if (
        k["taux_recla_temps"] is not None
        and k["taux_recla_temps"]
        < OBJECTIF_RECLAMATIONS
    ):

        alertes.append(
            (
                "Traitement des réclamations à surveiller",
                f"Le taux de traitement dans les délais "
                f"est de {_fmt_pct(k['taux_recla_temps'])}."
            )
        )

        actions.append(
            "Identifier les dossiers hors délai "
            "et suivre leur résolution."
        )

    # --------------------------------------------------------
    # CONTRE-PERFORMANCES
    # --------------------------------------------------------

    if k["cp"] > 0:

        alertes.append(
            (
                "Contre-performances signalées",
                f"{_fmt_nombre(k['cp'])} "
                "signalement(s) ont été renseignés."
            )
        )

        actions.append(
            "Examiner les motifs les plus fréquents "
            "des contre-performances."
        )

    # --------------------------------------------------------
    # INITIATIVES
    # --------------------------------------------------------

    if k["initiatives"] > 0:

        positifs.append(
            (
                "Actions renseignées",
                f"{_fmt_nombre(k['initiatives'])} "
                "initiative(s) ont été enregistrées."
            )
        )

    # --------------------------------------------------------
    # AFFICHAGE
    # --------------------------------------------------------

    c1, c2, c3 = st.columns(
        3,
        gap="large",
    )

    with c1:

        st.markdown(
            """
            <div class="insight-card">
                <div class="insight-title">
                    🔴 À SURVEILLER
                </div>
            """,
            unsafe_allow_html=True,
        )

        if not alertes:

            st.markdown(
                """
                <div class="insight-text">
                    Aucun point critique identifié
                    sur les indicateurs disponibles.
                </div>
                """,
                unsafe_allow_html=True,
            )

        else:

            for titre, texte in alertes:

                st.markdown(
                    f"""
                    <div class="alert-item">
                        <strong>{titre}</strong><br>
                        <span>{texte}</span>
                    </div>
                    """,
                    unsafe_allow_html=True,
                )

        st.markdown(
            "</div>",
            unsafe_allow_html=True,
        )

    with c2:

        st.markdown(
            """
            <div class="insight-card">
                <div class="insight-title">
                    🟢 POINTS POSITIFS
                </div>
            """,
            unsafe_allow_html=True,
        )

        if not positifs:

            st.markdown(
                """
                <div class="insight-text">
                    Aucun point positif
                    automatiquement identifié.
                </div>
                """,
                unsafe_allow_html=True,
            )

        else:

            for titre, texte in positifs:

                st.markdown(
                    f"""
                    <div class="alert-item">
                        <strong>{titre}</strong><br>
                        <span>{texte}</span>
                    </div>
                    """,
                    unsafe_allow_html=True,
                )

        st.markdown(
            "</div>",
            unsafe_allow_html=True,
        )

    with c3:

        st.markdown(
            """
            <div class="insight-card">
                <div class="insight-title">
                    🔵 ACTIONS RECOMMANDÉES
                </div>
            """,
            unsafe_allow_html=True,
        )

        if not actions:

            st.markdown(
                """
                <div class="insight-text">
                    Aucun plan d'action spécifique
                    n'est généré pour cette période.
                </div>
                """,
                unsafe_allow_html=True,
            )

        else:

            for action in actions:

                st.markdown(
                    f"""
                    <div class="alert-item">
                        <span>• {action}</span>
                    </div>
                    """,
                    unsafe_allow_html=True,
                )

        st.markdown(
            "</div>",
            unsafe_allow_html=True,
        )


# ============================================================
# TABLEAU D'ÉVOLUTION
# ============================================================

def _tableau_evolution(
    df_annee: pd.DataFrame,
    granularite: str,
):

    periodes = _construire_periodes(
        df_annee,
        granularite,
    )

    lignes = []

    precedent = None

    for periode in periodes:

        df_p = _filtrer_periode(
            df_annee,
            periode,
        )

        k = _kpi_periode(df_p)

        variation = _variation_pct(
            k["satisfaction_globale"],
            precedent,
        )

        lignes.append(
            {
                "Période": periode.label,
                "Satisfaction globale": (
                    _fmt_pct(
                        k["satisfaction_globale"]
                    )
                ),
                "Taux de satisfaction": (
                    _fmt_pct(
                        k["taux_satisfaction"]
                    )
                ),
                "Taux de recueil": (
                    _fmt_pct(
                        k["taux_recueil"]
                    )
                ),
                "Réclamations à temps": (
                    _fmt_pct(
                        k["taux_recla_temps"]
                    )
                ),
                "Clients reçus": (
                    _fmt_nombre(
                        k["clients_recus"]
                    )
                ),
                "Réponses": (
                    _fmt_nombre(
                        k["recueil"]
                    )
                ),
                "Variation": (
                    "—"
                    if variation is None
                    else f"{variation:+.1f}%".replace(
                        ".",
                        ",",
                    )
                ),
            }
        )

        if (
            k["satisfaction_globale"]
            is not None
        ):

            precedent = (
                k["satisfaction_globale"]
            )

    if not lignes:
        return

    tableau = pd.DataFrame(lignes)

    st.dataframe(
        tableau,
        use_container_width=True,
        hide_index=True,
        height=min(
            460,
            100 + len(tableau) * 36,
        ),
        key=f"satisfaction_tableau_evolution_{granularite}_{len(tableau)}",
    )


# ============================================================
# PAGE PRINCIPALE
# ============================================================

def render(
    df: pd.DataFrame,
):

    _inject_page_css()

    # ========================================================
    # VALIDATION
    # ========================================================

    if df is None or df.empty:

        st.warning(
            "Aucune donnée disponible dans "
            "la base RC & SATISFACTION."
        )

        return

    if "Date" not in df.columns:

        st.warning(
            "La colonne Date est absente "
            "de la base Satisfaction."
        )

        return

    df = _prepare_dates(df)

    if df.empty:

        st.warning(
            "Aucune date exploitable "
            "dans la base Satisfaction."
        )

        return

    # ========================================================
    # FILTRES
    # ========================================================

    section(
        "PARAMÈTRES D'ANALYSE"
    )

    f1, f2, f3 = st.columns(
        [1, 1, 1.7],
        gap="medium",
    )

    # --------------------------------------------------------
    # GRANULARITÉ
    # --------------------------------------------------------

    with f1:

        granularite = st.selectbox(
            "Granularité",
            GRANULARITES,
            index=(
                GRANULARITES.index("Mensuel")
                if "Mensuel" in GRANULARITES
                else 0
            ),
            key="satisfaction_granularite_v2",
        )

    # --------------------------------------------------------
    # ANNÉES DISPONIBLES
    # --------------------------------------------------------

    annees = sorted(
        df["Date"]
        .dt.year
        .dropna()
        .astype(int)
        .unique()
        .tolist()
    )

    if not annees:

        st.warning(
            "Aucune année disponible."
        )

        return

    # --------------------------------------------------------
    # ANNÉE
    # --------------------------------------------------------

    with f2:

        annee = st.selectbox(
            "Année",
            annees,
            index=len(annees) - 1,
            key="satisfaction_annee_v2",
        )

    # IMPORTANT :
    # l'année est filtrée avant de construire les périodes.

    df_annee = df.loc[
        df["Date"].dt.year == int(annee)
    ].copy()

    # --------------------------------------------------------
    # PÉRIODES
    # --------------------------------------------------------

    periodes = _construire_periodes(
        df_annee,
        granularite,
    )

    if not periodes:

        st.warning(
            f"Aucune période disponible "
            f"pour {annee}."
        )

        return

    with f3:

        labels = [
            periode.label
            for periode in periodes
        ]

        periode_label = st.selectbox(
            "Période",
            labels,
            index=len(labels) - 1,
            key="satisfaction_periode_v2",
        )

    periode = next(
        p
        for p in periodes
        if p.label == periode_label
    )

    # ========================================================
    # PÉRIODE PRÉCÉDENTE
    # ========================================================

    periode_avant = _periode_precedente(
        periode
    )

    df_actuel = _filtrer_periode(
        df,
        periode,
    )

    df_precedent = _filtrer_periode(
        df,
        periode_avant,
    )

    k_actuel = _kpi_periode(
        df_actuel
    )

    k_precedent = _kpi_periode(
        df_precedent
    )

    # ========================================================
    # EN-TÊTE
    # ========================================================

    _render_header(
        int(annee),
        periode,
    )

    # ========================================================
    # INDICATEURS STRATÉGIQUES
    # ========================================================

    section(
        "INDICATEURS CLÉS — SATISFACTION"
    )

    cols = st.columns(
        4,
        gap="medium",
    )

    with cols[0]:

        _render_kpi(
            "🎯",
            "Satisfaction globale",
            k_actuel[
                "satisfaction_globale"
            ],
            k_precedent[
                "satisfaction_globale"
            ],
            OBJECTIF_SATISFACTION,
            "Cible 75 %",
        )

    with cols[1]:

        _render_kpi(
            "⭐",
            "Taux de satisfaction",
            k_actuel[
                "taux_satisfaction"
            ],
            k_precedent[
                "taux_satisfaction"
            ],
            OBJECTIF_SATISFACTION,
            "Cible 75 %",
        )

    with cols[2]:

        _render_kpi(
            "👥",
            "Taux de recueil",
            k_actuel[
                "taux_recueil"
            ],
            k_precedent[
                "taux_recueil"
            ],
            OBJECTIF_RECUEIL,
            "Cible 80 %",
        )

    with cols[3]:

        _render_kpi(
            "⏱️",
            "Réclamations traitées dans les délais",
            k_actuel[
                "taux_recla_temps"
            ],
            k_precedent[
                "taux_recla_temps"
            ],
            OBJECTIF_RECLAMATIONS,
            "Cible 100 %",
        )

    # ========================================================
    # VOLUMES
    # ========================================================

    section(
        "VOLUMES D'ACTIVITÉ"
    )

    cols = st.columns(
        4,
        gap="medium",
    )

    with cols[0]:

        _render_kpi(
            "👥",
            "Clients reçus",
            k_actuel[
                "clients_recus"
            ],
            k_precedent[
                "clients_recus"
            ],
            None,
            "Volume de clients",
        )

    with cols[1]:

        _render_kpi(
            "📝",
            "Réponses recueillies",
            k_actuel[
                "recueil"
            ],
            k_precedent[
                "recueil"
            ],
            None,
            "Réponses de satisfaction",
        )

    with cols[2]:

        _render_kpi(
            "😊",
            "Clients satisfaits",
            k_actuel[
                "clients_satisfaits"
            ],
            k_precedent[
                "clients_satisfaits"
            ],
            None,
            "Réponses satisfaites",
        )

    with cols[3]:

        _render_kpi(
            "📨",
            "Réclamations reçues",
            k_actuel[
                "reclamations_recues"
            ],
            k_precedent[
                "reclamations_recues"
            ],
            None,
            "Réclamations du mois",
        )

    # ========================================================
    # SIGNALEMENTS ET ACTIONS
    # ========================================================

    section(
        "SIGNALEMENTS ET ACTIONS"
    )

    cols = st.columns(
        4,
        gap="medium",
    )

    with cols[0]:

        _render_kpi(
            "⚠️",
            "Contre-performances signalées",
            k_actuel["cp"],
            k_precedent["cp"],
            None,
            "Commentaires renseignés",
            inverse=True,
        )

    with cols[1]:

        _render_kpi(
            "🚀",
            "Initiatives renseignées",
            k_actuel["initiatives"],
            k_precedent["initiatives"],
            None,
            "Actions enregistrées",
        )

    with cols[2]:

        _render_kpi(
            "📝",
            "Observations renseignées",
            k_actuel["observations"],
            k_precedent["observations"],
            None,
            "Observations terrain",
        )

    with cols[3]:

        _render_kpi(
            "🔄",
            "Mises à jour journalières",
            k_actuel["mises_a_jour"],
            k_precedent["mises_a_jour"],
            None,
            "Mises à jour enregistrées",
        )

    # ========================================================
    # BAROMÈTRE
    # ========================================================

    st.markdown(
        f"""
        <div class="pilotage-box">
            <div class="pilotage-title">
                BAROMÈTRE DE RÉFÉRENCE
            </div>
            <div class="pilotage-text">
                La grande enquête barométrique est de
                <strong>{k_actuel['grande_enquete']:.1f}%</strong>.
                Elle représente 50 % de la satisfaction globale.
                Les autres composantes sont le taux de satisfaction
                et le traitement des réclamations dans les délais.
            </div>
        </div>
        """,
        unsafe_allow_html=True,
    )

    # ========================================================
    # ÉVOLUTION
    # ========================================================

    section(
        "ÉVOLUTION DE LA PERFORMANCE"
    )

    c1, c2 = st.columns(
        2,
        gap="large",
    )

    with c1:

        st.markdown(
            """
            <div class="insight-card">
                <div class="insight-title">
                    ÉVOLUTION DES TAUX
                </div>
                <div class="insight-text">
                    Suivi de la satisfaction,
                    du recueil et du traitement
                    des réclamations.
                </div>
            </div>
            """,
            unsafe_allow_html=True,
        )

        _graphique_evolution_taux(
            df_annee,
            granularite,
            int(annee),
        )

    with c2:

        st.markdown(
            """
            <div class="insight-card">
                <div class="insight-title">
                    ÉVOLUTION DES VOLUMES
                </div>
                <div class="insight-text">
                    Comparaison des clients reçus,
                    réponses recueillies et clients satisfaits.
                </div>
            </div>
            """,
            unsafe_allow_html=True,
        )

        _graphique_volumes(
            df_annee,
            granularite,
            int(annee),
        )

    # ========================================================
    # RÉCLAMATIONS
    # ========================================================

    section(
        "PILOTAGE DES RÉCLAMATIONS"
    )

    r1, r2 = st.columns(
        [1.15, 1],
        gap="large",
    )

    with r1:

        st.markdown(
            """
            <div class="insight-card">
                <div class="insight-title">
                    RÉCLAMATIONS REÇUES ET TRAITÉES
                </div>
                <div class="insight-text">
                    Évolution du volume reçu et du volume
                    traité dans les délais.
                </div>
            </div>
            """,
            unsafe_allow_html=True,
        )

        _graphique_reclamations(
            df_annee,
            granularite,
        )

    with r2:

        st.markdown(
            """
            <div class="insight-card">
                <div class="insight-title">
                    TABLEAU DE PILOTAGE
                </div>
                <div class="insight-text">
                    Vision mensuelle, annuelle et Commission.
                </div>
            </div>
            """,
            unsafe_allow_html=True,
        )

        _render_tableau_reclamations(
            k_actuel
        )

    # ========================================================
    # CONTRE-PERFORMANCES
    # ========================================================

    section(
        "CONTRE-PERFORMANCES — ANALYSE DES MOTIFS"
    )

    cp1, cp2 = st.columns(
        2,
        gap="large",
    )

    with cp1:

        st.markdown(
            """
            <div class="insight-card">
                <div class="insight-title">
                    MOTIFS DES CONTRE-PERFORMANCES
                </div>
                <div class="insight-text">
                    Les contre-performances sont analysées
                    comme des commentaires renseignés.
                </div>
            </div>
            """,
            unsafe_allow_html=True,
        )

        _graphique_commentaires(
            df_actuel,
            "Contre Performance",
            "Motifs",
            ROUGE,
        )

    with cp2:

        st.markdown(
            """
            <div class="insight-card">
                <div class="insight-title">
                    ÉVOLUTION DES SIGNALEMENTS
                </div>
                <div class="insight-text">
                    Nombre de contre-performances renseignées
                    au fil des périodes.
                </div>
            </div>
            """,
            unsafe_allow_html=True,
        )

        _graphique_evolution_commentaire(
            df_annee,
            granularite,
            "Contre Performance",
            ROUGE,
            "cp",
        )

    # ========================================================
    # INITIATIVES
    # ========================================================

    section(
        "INITIATIVES — ACTIONS MENÉES"
    )

    i1, i2 = st.columns(
        2,
        gap="large",
    )

    with i1:

        st.markdown(
            """
            <div class="insight-card">
                <div class="insight-title">
                    PRINCIPALES INITIATIVES
                </div>
                <div class="insight-text">
                    Répartition des actions renseignées
                    dans la base.
                </div>
            </div>
            """,
            unsafe_allow_html=True,
        )

        _graphique_commentaires(
            df_actuel,
            "Initiative",
            "Initiatives",
            GOLD,
        )

    with i2:

        st.markdown(
            """
            <div class="insight-card">
                <div class="insight-title">
                    ÉVOLUTION DES INITIATIVES
                </div>
                <div class="insight-text">
                    Dynamique des actions renseignées
                    au cours de l'année.
                </div>
            </div>
            """,
            unsafe_allow_html=True,
        )

        _graphique_evolution_commentaire(
            df_annee,
            granularite,
            "Initiative",
            GOLD,
            "initiatives",
        )

    # ========================================================
    # OBSERVATIONS
    # ========================================================

    section(
        "OBSERVATIONS TERRAIN"
    )

    o1, o2 = st.columns(
        [1, 1.15],
        gap="large",
    )

    with o1:

        st.markdown(
            """
            <div class="insight-card">
                <div class="insight-title">
                    PRINCIPAUX SIGNALEMENTS
                </div>
                <div class="insight-text">
                    Les observations sont regroupées
                    pour faire ressortir les situations
                    les plus fréquentes.
                </div>
            </div>
            """,
            unsafe_allow_html=True,
        )

        _graphique_commentaires(
            df_actuel,
            "Observations",
            "Observations",
            BLUE_ACCENT,
        )

    with o2:

        st.markdown(
            """
            <div class="insight-card">
                <div class="insight-title">
                    DÉTAIL DES OBSERVATIONS
                </div>
                <div class="insight-text">
                    Consultation des observations
                    renseignées sur la période.
                </div>
            </div>
            """,
            unsafe_allow_html=True,
        )

        _render_observations(
            df_actuel
        )

    # ========================================================
    # TABLEAU D'ÉVOLUTION
    # ========================================================

    section(
        "TABLEAU DE SUIVI DE LA PÉRIODE"
    )

    st.markdown(
        """
        <div class="insight-card">
            <div class="insight-title">
                LECTURE PÉRIODE PAR PÉRIODE
            </div>
            <div class="insight-text">
                Les variations sont exprimées en pourcentage
                par rapport à la période immédiatement précédente.
            </div>
        </div>
        """,
        unsafe_allow_html=True,
    )

    _tableau_evolution(
        df_annee,
        granularite,
    )

    # ========================================================
    # ANALYSE DÉCISIONNELLE
    # ========================================================

    section(
        "ANALYSE DÉCISIONNELLE"
    )

    _render_analyse_decisionnelle(
        k_actuel,
        k_precedent,
    )

    # ========================================================
    # MÉTHODOLOGIE
    # ========================================================

    with st.expander(
        "Méthodologie des indicateurs",
        expanded=False,
    ):

        st.markdown(
            f"""
            **Satisfaction globale**

            La satisfaction globale est calculée à partir
            du baromètre, du taux de satisfaction et du
            traitement des réclamations dans les délais.

            **Taux de satisfaction**

            Clients satisfaits / réponses recueillies.

            **Taux de recueil**

            Réponses recueillies / clients reçus.

            **Taux de traitement dans les délais**

            Réclamations du mois traitées dans les délais /
            réclamations du mois reçues.

            **Contre-performances**

            Les contre-performances sont des commentaires.
            Elles sont donc comptabilisées comme des
            signalements renseignés et non comme une
            valeur numérique.

            **Initiatives**

            Les initiatives sont des actions renseignées
            dans la base. Elles sont comptabilisées comme
            des actions signalées.

            **Variations**

            Toutes les variations affichées dans cette page
            sont des variations relatives en pourcentage
            par rapport à la période précédente.

            Les indicateurs annuels et Commission sont traités
            comme des valeurs cumulatives : la dernière valeur
            disponible de la période est utilisée afin d'éviter
            de sommer plusieurs fois un cumul annuel.
            """
        )